document.addEventListener('DOMContentLoaded', () => {
    // 状態管理
    let cookies = 0;
    let jewels = 0;
    let totalCps = 0;
    let totalBaked = 0;
    let playerLevel = 1;
    let bonusesEarned = 0;
    let gameStartDate = new Date().toLocaleString();
    let maxCombo = 0;
    let currentCombo = 0;
    let lastClickTime = 0;
    
    // フィーバー関連
    let isFeverActive = false;
    let feverMultiplier = 7;
    let feverTimeLeft = 0;
    const FEVER_DURATION = 20; // 20秒
    const ADS_CONFIG = {
        android: {
            appId: 'ca-app-pub-9138341481603997~2199897351',
            rewardedAdUnitId: 'ca-app-pub-9138341481603997/1649233015'
        },
        ios: {
            appId: 'ca-app-pub-9138341481603997~9411113474',
            rewardedAdUnitId: 'ca-app-pub-9138341481603997/3187665067'
        }
    };
    const CURRENT_APP_VERSION = '1.0.0';
    const LATEST_APP_VERSION = '1.0.1';
    const UPDATE_STORE_URL = 'https://apps.apple.com/';
    let rewardedAdBusy = false;
    let admobInitialized = false;

    function wait(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    function getAdPlatform() {
        if (window.Capacitor?.getPlatform) {
            const platform = window.Capacitor.getPlatform();
            if (platform === 'ios' || platform === 'android') return platform;
        }

        const ua = navigator.userAgent || '';
        if (/iphone|ipad|ipod/i.test(ua)) return 'ios';
        if (/android/i.test(ua)) return 'android';
        return 'android';
    }

    function compareVersions(current, latest) {
        const currentParts = current.split('.').map(part => parseInt(part, 10) || 0);
        const latestParts = latest.split('.').map(part => parseInt(part, 10) || 0);
        const maxLength = Math.max(currentParts.length, latestParts.length);

        for (let i = 0; i < maxLength; i++) {
            const currentValue = currentParts[i] || 0;
            const latestValue = latestParts[i] || 0;
            if (latestValue > currentValue) return -1;
            if (latestValue < currentValue) return 1;
        }

        return 0;
    }

    function shouldShowUpdateDialog() {
        return compareVersions(CURRENT_APP_VERSION, LATEST_APP_VERSION) === -1;
    }

    async function showBrandSplash() {
        if (!brandSplash || !brandLogo) return;

        await wait(100);
        brandLogo.classList.add('fade-in');
        await wait(1500);

        let tapText = brandSplash.querySelector('.brand-splash-tap');
        if (!tapText) {
            tapText = document.createElement('p');
            tapText.textContent = 'タップしてスタート';
            tapText.className = 'brand-splash-tap';
            brandSplash.appendChild(tapText);
        }

        brandSplash.style.pointerEvents = 'auto';

        await new Promise(resolve => {
            const onTap = (e) => {
                e.preventDefault();
                e.stopPropagation();
                brandSplash.removeEventListener('click', onTap, true);
                brandSplash.removeEventListener('touchend', onTap, true);
                resolve();
            };
            brandSplash.addEventListener('click', onTap, true);
            brandSplash.addEventListener('touchend', onTap, true);
        });

        brandSplash.style.pointerEvents = 'none';
        brandSplash.classList.add('fade-out');
        await wait(1000);
        brandSplash.remove();
    }

    async function showUpdateDialogIfNeeded() {
        if (!updateModal || !shouldShowUpdateDialog()) return;

        currentVersionLabel.textContent = `現在: ${CURRENT_APP_VERSION}`;
        latestVersionLabel.textContent = `最新: ${LATEST_APP_VERSION}`;
        updateMessage.textContent = '新しいバージョンがあります。今すぐ更新すると最新機能が使えます。';
        updateModal.classList.remove('hidden');

        await new Promise(resolve => {
            const handleLater = () => {
                cleanup();
                updateModal.classList.add('hidden');
                resolve();
            };
            const handleUpdate = () => {
                cleanup();
                window.open(UPDATE_STORE_URL, '_blank');
                updateModal.classList.add('hidden');
                resolve();
            };
            const cleanup = () => {
                updateLaterBtn.removeEventListener('click', handleLater);
                updateNowBtn.removeEventListener('click', handleUpdate);
            };

            updateLaterBtn.addEventListener('click', handleLater);
            updateNowBtn.addEventListener('click', handleUpdate);
        });
    }

    async function runStartupSequence() {
        loadGame();
        calculateCps();
        updateDisplay();
        await showBrandSplash();
        await showUpdateDialogIfNeeded();
        checkOfflineBonus();
        checkDailyBonus();
        updateDisplay();
    }

    function syncAppHeight() {
        const viewportHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;
        document.documentElement.style.setProperty('--app-height', `${viewportHeight * 0.01}px`);
    }

    function getViewportCenter() {
        const viewportWidth = window.visualViewport ? window.visualViewport.width : window.innerWidth;
        const viewportHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;
        return {
            x: viewportWidth / 2,
            y: viewportHeight / 2
        };
    }

    function clampEffectPosition(x, y) {
        const viewportWidth = window.visualViewport ? window.visualViewport.width : window.innerWidth;
        const viewportHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;
        return {
            x: Math.max(24, Math.min(viewportWidth - 24, x)),
            y: Math.max(48, Math.min(viewportHeight - 48, y))
        };
    }

    syncAppHeight();
    window.addEventListener('resize', syncAppHeight);
    window.addEventListener('orientationchange', syncAppHeight);
    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', syncAppHeight);
    }

    let upgrades = {
        'buy-cursor': { count: 0, cost: 15, baseCost: 15, cps: 0.1 },
        'buy-grandma': { count: 0, cost: 100, baseCost: 100, cps: 1.0 },
        'buy-factory': { count: 0, cost: 1100, baseCost: 1100, cps: 8.0 },
        'buy-donut': { count: 0, cost: 12000, baseCost: 12000, cps: 47 },
        'buy-icecream': { count: 0, cost: 130000, baseCost: 130000, cps: 260 },
        'buy-mine': { count: 0, cost: 1400000, baseCost: 1400000, cps: 1400 },
        'buy-fountain': { count: 0, cost: 20000000, baseCost: 20000000, cps: 7800 },
        'buy-bakery': { count: 0, cost: 330000000, baseCost: 330000000, cps: 44000 },
        'buy-planet': { count: 0, cost: 5100000000, baseCost: 5100000000, cps: 260000 }
    };

    // ボーナス・広告関連
    let adBoostActive = false;
    let boostEndTime = 0;
    let lastSaveTime = Date.now();
    let lastLoginDate = "";
    let pendingOfflineCookies = 0;
    let soundEnabled = true;
    let cooldowns = {
        'fever': 0,
        'jewel': 0,
        'boost': 0
    };
    const COOLDOWN_DURATIONS = {
        'fever': 120, // 2分
        'jewel': 300, // 5分
        'boost': 600  // 10分
    };

    // DOM要素の取得
    const cookieBtn = document.getElementById('cookie-btn');
    const cookieCountDisplay = document.getElementById('cookie-count');
    const jewelCountDisplay = document.getElementById('jewel-count');
    const cpsDisplay = document.getElementById('cps');
    const playerLevelText = document.getElementById('player-level-text');
    const playerLevelBox = document.getElementById('player-level-box');
    const playerLevelProgress = document.getElementById('player-level-progress');
    const autoclickerStatus = document.getElementById('autoclicker-status');
    const playArea = document.getElementById('play-area');
    
    // パネル操作用
    const buildingsPanel = document.getElementById('buildings-panel');
    const upgradesPanel = document.getElementById('upgrades-panel');
    const bonusPanel = document.getElementById('bonus-panel');
    const statsPanel = document.getElementById('stats-panel');
    const navTabs = document.querySelectorAll('.nav-tab');
    const closePanelBtns = document.querySelectorAll('.close-panel');
    const buildingBadge = document.getElementById('building-badge');
    const upgradeBadge = document.getElementById('upgrade-badge');
    const bonusBadge = document.getElementById('bonus-badge');

    // 広告用DOM
    const adOverlay = document.getElementById('ad-simulation-overlay');
    const adTimerCount = document.getElementById('ad-timer-count');
    const adProgress = document.getElementById('ad-progress');

    // オフラインモーダル用DOM
    const offlineModal = document.getElementById('offline-modal');
    const offlineCookiesDisplay = document.getElementById('offline-cookies-amount');
    const claimOfflineBtn = document.getElementById('claim-offline-btn');
    const adDoubleOfflineBtn = document.getElementById('ad-double-offline-btn');

    // デイリーボーナス用DOM
    const dailyModal = document.getElementById('daily-modal');
    const dailyCookiesReward = document.getElementById('daily-cookies-reward');
    const claimDailyBtn = document.getElementById('claim-daily-btn');
    const adTripleDailyBtn = document.getElementById('ad-triple-daily-btn');

    // 設定パネル用DOM
    const settingsPanel = document.getElementById('settings-panel');
    const settingsBtn = document.getElementById('settings-btn');
    const soundToggleBtn = document.getElementById('sound-toggle-btn');
    const resetBtnMain = document.getElementById('reset-btn-main');

    // 課金モーダル用DOM
    const billingModal = document.getElementById('billing-modal');
    const billingProductName = document.getElementById('billing-product-name');
    const billingProductPrice = document.getElementById('billing-product-price');
    const billingCancelBtn = document.getElementById('billing-cancel-btn');
    const billingConfirmBtn = document.getElementById('billing-confirm-btn');
    let pendingBillingAmount = 0;

    // コンボ表示用DOM
    const comboDisplay = document.getElementById('combo-display');
    const brandSplash = document.getElementById('brand-splash');
    const brandLogo = document.getElementById('brand-logo');
    const updateModal = document.getElementById('update-modal');
    const updateMessage = document.getElementById('update-message');
    const currentVersionLabel = document.getElementById('current-version-label');
    const latestVersionLabel = document.getElementById('latest-version-label');
    const updateLaterBtn = document.getElementById('update-later-btn');
    const updateNowBtn = document.getElementById('update-now-btn');

    // アップグレード状態管理
    let passiveBuffs = {
        'upgrade-click': { purchased: false, level: 1, cost: 500, type: 'click', multiplier: 2 },
        'upgrade-grandma': { purchased: false, level: 1, cost: 1000, type: 'building', target: 'buy-grandma', multiplier: 2 },
        'upgrade-factory': { purchased: false, level: 1, cost: 10000, type: 'building', target: 'buy-factory', multiplier: 2 },
        'upgrade-fever': { purchased: false, level: 1, cost: 50000, type: 'fever', extend: 10 },
        'upgrade-global': { purchased: false, level: 1, cost: 100000, type: 'global', multiplier: 1.2 }
    };

    // プレミアム強化状態管理
    let premiumUpgrades = {
        'premium-fever': { purchased: false, level: 0, baseCost: 10, type: 'multiplier', value: 10 },
        'premium-spawn': { purchased: false, level: 0, baseCost: 15, type: 'spawn', rate: 2 },
        'premium-autoclick': { purchased: false, level: 0, baseCost: 20, type: 'autoclick', speed: 1000 }
    };

    // フィーバー用DOM
    const feverTimerContainer = document.getElementById('fever-timer-container');
    const feverProgress = document.getElementById('fever-progress');
    const goldenSweetContainer = document.getElementById('golden-sweet-container');

    // 統計表示用
    const statBonuses = document.getElementById('stat-bonuses');
    const statStartDate = document.getElementById('stat-start-date');
    const statTotalBaked = document.getElementById('stat-total-baked');
    const statTotalBuildings = document.getElementById('stat-total-buildings');
    const statCookiesPerClick = document.getElementById('stat-cookies-per-click');
    const statMaxCombo = document.getElementById('stat-max-combo');

    // タブクリックでパネル表示
    navTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.getAttribute('data-target');
            if (target === 'buildings') {
                buildingsPanel.classList.remove('hidden');
                statsPanel.classList.add('hidden');
                bonusPanel.classList.add('hidden');
                upgradesPanel.classList.add('hidden');
                settingsPanel.classList.add('hidden');
            } else if (target === 'upgrades-panel') {
                upgradesPanel.classList.remove('hidden');
                buildingsPanel.classList.add('hidden');
                statsPanel.classList.add('hidden');
                bonusPanel.classList.add('hidden');
                settingsPanel.classList.add('hidden');
                updateDisplay(); 
            } else if (target === 'bonus-panel') {
                bonusPanel.classList.remove('hidden');
                buildingsPanel.classList.add('hidden');
                statsPanel.classList.add('hidden');
                upgradesPanel.classList.add('hidden');
                settingsPanel.classList.add('hidden');
                updateDisplay();
            } else if (target === 'stats-panel') {
                statsPanel.classList.remove('hidden');
                buildingsPanel.classList.add('hidden');
                upgradesPanel.classList.add('hidden');
                bonusPanel.classList.add('hidden');
                settingsPanel.classList.add('hidden');
                updateDisplay(); 
            }
        });
    });

    closePanelBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            buildingsPanel.classList.add('hidden');
            upgradesPanel.classList.add('hidden');
            bonusPanel.classList.add('hidden');
            statsPanel.classList.add('hidden');
            settingsPanel.classList.add('hidden');
        });
    });

    // フィーバータイムの開始
    function startFeverTime() {
        const mult = premiumUpgrades['premium-fever'].purchased ? premiumUpgrades['premium-fever'].value : feverMultiplier;
        
        // 基本20秒 + 強化ボーナス(10秒 + Lvごとに2秒追加)
        const bonusDuration = passiveBuffs['upgrade-fever'].purchased ? (10 + (passiveBuffs['upgrade-fever'].level - 1) * 2) : 0;
        const totalDuration = FEVER_DURATION + bonusDuration;

        if (isFeverActive) {
            feverTimeLeft = totalDuration;
            return;
        }

        isFeverActive = true;
        feverTimeLeft = totalDuration;
        bonusesEarned++;
        
        playArea.classList.add('fever-mode');
        feverTimerContainer.classList.remove('hidden');
        feverTimerContainer.querySelector('.fever-label').textContent = `Fever Time! x${mult}`;
        
        // フィーバー開始音 (少し高めの音)
        playSpecialSound(880, 0.3);

        const feverInterval = setInterval(() => {
            feverTimeLeft -= 0.1;
            const progress = (feverTimeLeft / totalDuration) * 100;
            feverProgress.style.width = `${progress}%`;

            if (feverTimeLeft <= 0) {
                clearInterval(feverInterval);
                endFeverTime();
            }
        }, 100);
        
        updateDisplay();
    }

    function endFeverTime() {
        isFeverActive = false;
        feverTimeLeft = 0;
        playArea.classList.remove('fever-mode');
        feverTimerContainer.classList.add('hidden');
        updateDisplay();
    }

    // ゴールデンお菓子の出現
    function spawnGoldenSweet() {
        const sweet = document.createElement('div');
        sweet.id = 'golden-sweet';
        sweet.textContent = '🌟';
        
        const x = 10 + Math.random() * 80;
        const y = 20 + Math.random() * 60;
        sweet.style.left = `${x}%`;
        sweet.style.top = `${y}%`;

        sweet.addEventListener('click', (e) => {
            // ジュエルの獲得 (1-3個)
            const jewelGain = Math.floor(Math.random() * 3) + 1;
            jewels += jewelGain;
            spawnFloatText(e.clientX, e.clientY, `+💎${jewelGain}`);
            
            startFeverTime();
            sweet.remove();
            updateDisplay();
            saveGame();
        });

        goldenSweetContainer.appendChild(sweet);
        setTimeout(() => {
            if (sweet.parentNode) sweet.remove();
        }, 8000);
    }

    // ゴールデンお菓子の出現ループ
    function goldenSweetLoop() {
        const baseMin = 60;
        const baseMax = 120;
        // 基本1 + プレミアムレベル (Lv.1で2倍、Lv.2で3倍...)
        const divisor = 1 + premiumUpgrades['premium-spawn'].level;
        const nextSpawn = ((baseMin + Math.random() * (baseMax - baseMin)) / divisor) * 1000;
        
        setTimeout(() => {
            spawnGoldenSweet();
            goldenSweetLoop();
        }, nextSpawn);
    }
    goldenSweetLoop();

    function getLevelTarget(level) {
        if (level <= 1) return 0;
        return Math.floor(100 * Math.pow(level - 1, 2.2));
    }

    function getClickLevelBonusMultiplier() {
        return 1 + ((playerLevel - 1) * 0.01);
    }

    function getCpsLevelBonusMultiplier() {
        return 1 + (Math.floor(playerLevel / 5) * 0.02);
    }

    function spawnMilestoneMessage(level) {
        const message = document.createElement('div');
        message.className = 'milestone-level-text';
        const title = level === 10 ? 'MASTER!' : level === 20 ? 'LEGEND!' : level === 30 ? 'GODLIKE!' : 'ULTIMATE!';
        message.textContent = `LEVEL ${level} ${title}`;
        document.body.appendChild(message);
        setTimeout(() => message.remove(), 1800);
    }

    function triggerMilestoneLevelEffect(level) {
        const viewportCenter = getViewportCenter();
        const flash = document.createElement('div');
        flash.className = 'milestone-flash';
        document.body.appendChild(flash);
        setTimeout(() => flash.remove(), 700);

        const particles = ['👑', '🏆', '✨', '💎'];
        for (let i = 0; i < 24; i++) {
            const particle = document.createElement('div');
            particle.className = 'purchase-particle';
            particle.textContent = particles[i % particles.length];
            particle.style.left = '50%';
            particle.style.top = '50%';
            document.body.appendChild(particle);

            const angle = (Math.random() * 360) * (Math.PI / 180);
            const velocity = 8 + Math.random() * 14;
            const vx = Math.cos(angle) * velocity;
            const vy = Math.sin(angle) * velocity - 12;

            let x = viewportCenter.x;
            let y = viewportCenter.y;
            let curVx = vx;
            let curVy = vy;
            const gravity = 0.45;

            const animate = () => {
                x += curVx;
                y += curVy;
                curVy += gravity;
                particle.style.transform = `translate(${x - viewportCenter.x}px, ${y - viewportCenter.y}px) scale(1.1) rotate(${curVy * 10}deg)`;
                particle.style.opacity = parseFloat(particle.style.opacity || 1) - 0.018;

                if (y < (window.visualViewport ? window.visualViewport.height : window.innerHeight) + 80 && parseFloat(particle.style.opacity) > 0) {
                    requestAnimationFrame(animate);
                } else {
                    particle.remove();
                }
            };

            requestAnimationFrame(animate);
        }

        spawnMilestoneMessage(level);
        playSpecialSound(1320, 0.35);
        setTimeout(() => playSpecialSound(1760, 0.4), 120);
    }

    function grantLevelReward(level) {
        const baseReward = Math.max(100, Math.floor(getLevelTarget(level + 1) * 0.08));
        let rewardCookies = baseReward;
        let rewardJewels = 0;

        if (level % 5 === 0) {
            rewardCookies += Math.max(500, Math.floor(getLevelTarget(level + 1) * 0.12));
            rewardJewels += Math.floor(level / 5) * 3;
        }

        if (level % 10 === 0) {
            rewardCookies += Math.max(2000, Math.floor(getLevelTarget(level + 1) * 0.2));
            rewardJewels += 10;
        }

        cookies += rewardCookies;
        jewels += rewardJewels;

        playerLevelBox.classList.add('level-up');
        setTimeout(() => playerLevelBox.classList.remove('level-up'), 600);
        if (level % 10 === 0) {
            triggerMilestoneLevelEffect(level);
        } else {
            playSpecialSound(990, 0.25);
            triggerPurchaseEffect('⭐');
        }

        const rewardText = rewardJewels > 0
            ? `LEVEL UP! Lv.${level} +${Math.floor(rewardCookies).toLocaleString()} / +💎${rewardJewels}`
            : `LEVEL UP! Lv.${level} +${Math.floor(rewardCookies).toLocaleString()}`;
        const viewportCenter = getViewportCenter();
        spawnFloatText(viewportCenter.x, viewportCenter.y, rewardText);
    }

    function checkLevelUp() {
        while (totalBaked >= getLevelTarget(playerLevel + 1)) {
            playerLevel++;
            grantLevelReward(playerLevel);
        }
    }

    // プレミアム強化の購入処理
    document.querySelectorAll('.buy-premium-btn:not(.charge)').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const upgradeId = e.target.closest('.upgrade-item').id;
            const upgrade = premiumUpgrades[upgradeId];
            
            // コスト計算 (レベルに応じて2倍ずつ増加)
            const currentCost = upgrade.baseCost * Math.pow(2, upgrade.level);

            if (jewels >= currentCost) {
                jewels -= currentCost;
                upgrade.level++;
                upgrade.purchased = true;
                
                // 特定の効果適用 (オートクリッカー開始など)
                if (upgradeId === 'premium-autoclick') {
                    startAutoClicker();
                }
                
                updateDisplay();
                saveGame();
                triggerPurchaseEffect('💎');
            }
        });
    });

    // 課金アイテムのクリック処理
    document.querySelectorAll('.billing-item').forEach(item => {
        item.addEventListener('click', () => {
            const amount = parseInt(item.getAttribute('data-amount'));
            const price = item.getAttribute('data-price');
            const name = item.querySelector('.item-name').textContent;

            pendingBillingAmount = amount;
            billingProductName.textContent = name;
            billingProductPrice.textContent = price;
            billingModal.classList.remove('hidden');
        });
    });

    billingCancelBtn.addEventListener('click', () => {
        billingModal.classList.add('hidden');
        pendingBillingAmount = 0;
    });

    billingConfirmBtn.addEventListener('click', () => {
        if (pendingBillingAmount > 0) {
            jewels += pendingBillingAmount;
            triggerPurchaseEffect('💎');
            const viewportCenter = getViewportCenter();
            spawnFloatText(viewportCenter.x, viewportCenter.y, `+💎${pendingBillingAmount} PURCHASED!`);
            
            billingModal.classList.add('hidden');
            pendingBillingAmount = 0;
            updateDisplay();
            saveGame();
        }
    });

    // 広告ボーナスの処理
    document.querySelectorAll('.ad-reward-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const type = btn.getAttribute('data-type');
            if (Date.now() < cooldowns[type]) return;

            let duration = 5;
            if (type === 'fever') duration = 5;
            if (type === 'jewel') duration = 10;
            if (type === 'boost') duration = 15;

            const rewarded = await requestRewardedAd(type, duration);
            if (!rewarded) return;

                giveAdReward(type);
                cooldowns[type] = Date.now() + COOLDOWN_DURATIONS[type] * 1000;
                updateDisplay();
                saveGame();
        });
    });

    function getRewardedAdUnitId() {
        const platform = getAdPlatform();
        return ADS_CONFIG[platform]?.rewardedAdUnitId || ADS_CONFIG.android.rewardedAdUnitId;
    }

    function hasNativeRewardedAdBridge() {
        return Boolean(
            window.AndroidRewardedAd?.showRewardedAd ||
            window.Capacitor?.Plugins?.AdMobBridge?.showRewardedAd ||
            window.Capacitor?.Plugins?.AdMob?.showRewardedAd ||
            (window.Capacitor?.Plugins?.AdMob?.prepareRewardVideoAd && window.Capacitor?.Plugins?.AdMob?.showRewardVideoAd)
        );
    }

    async function initializeAdMobPlugin() {
        const admobPlugin = window.Capacitor?.Plugins?.AdMob;
        if (!admobPlugin || admobInitialized || !admobPlugin.initialize) return;

        await admobPlugin.initialize();
        admobInitialized = true;
    }

    async function showCommunityRewardedAd(payload) {
        const admobPlugin = window.Capacitor?.Plugins?.AdMob;
        if (!admobPlugin?.prepareRewardVideoAd || !admobPlugin?.showRewardVideoAd) return null;

        await initializeAdMobPlugin();

        if (!admobPlugin.addListener) {
            await admobPlugin.prepareRewardVideoAd({
                adId: payload.adUnitId,
                isTesting: true
            });
            await admobPlugin.showRewardVideoAd();
            return true;
        }

        let rewardEarned = false;
        let resolved = false;
        const listenerHandles = [];

        const clearListeners = async () => {
            await Promise.all(listenerHandles.map(async handle => {
                if (handle?.remove) {
                    await handle.remove();
                }
            }));
        };

        const finish = async (value, resolve) => {
            if (resolved) return;
            resolved = true;
            await clearListeners();
            resolve(value);
        };

        return new Promise(async resolve => {
            try {
                listenerHandles.push(await admobPlugin.addListener('onRewardedVideoAdReward', () => {
                    rewardEarned = true;
                }));
                listenerHandles.push(await admobPlugin.addListener('onRewardedVideoAdDismissed', async () => {
                    await finish(rewardEarned, resolve);
                }));
                listenerHandles.push(await admobPlugin.addListener('onRewardedVideoAdFailedToLoad', async (info) => {
                    await finish(false, resolve);
                }));
                listenerHandles.push(await admobPlugin.addListener('onRewardedVideoAdFailedToShow', async (info) => {
                    await finish(false, resolve);
                }));

                await admobPlugin.prepareRewardVideoAd({
                    adId: payload.adUnitId,
                    isTesting: true
                });
                await admobPlugin.showRewardVideoAd();
            } catch (error) {
                console.error('Community AdMob rewarded flow failed:', error);
                await finish(false, resolve);
            }
        });
    }

    async function showNativeRewardedAd(type) {
        const platform = getAdPlatform();
        const payload = {
            type,
            adUnitId: getRewardedAdUnitId(),
            appId: ADS_CONFIG[platform]?.appId || ADS_CONFIG.android.appId,
            platform
        };

        if (window.AndroidRewardedAd?.showRewardedAd) {
            const result = await window.AndroidRewardedAd.showRewardedAd(JSON.stringify(payload));
            return result === 'true' || result === true;
        }

        if (window.Capacitor?.Plugins?.AdMobBridge?.showRewardedAd) {
            const result = await window.Capacitor.Plugins.AdMobBridge.showRewardedAd(payload);
            return result?.rewarded !== false;
        }

        if (window.Capacitor?.Plugins?.AdMob?.showRewardedAd) {
            const result = await window.Capacitor.Plugins.AdMob.showRewardedAd(payload);
            return result?.rewarded !== false;
        }

        const communityRewarded = await showCommunityRewardedAd(payload);
        if (communityRewarded !== null) {
            return communityRewarded;
        }

        return false;
    }

    function startAdSimulation(duration) {
        return new Promise(resolve => {
            adOverlay.classList.remove('hidden');
            let timeLeft = duration;
            adTimerCount.textContent = timeLeft;
            adProgress.style.width = '0%';

            const interval = setInterval(() => {
                timeLeft--;
                adTimerCount.textContent = timeLeft;
                adProgress.style.width = `${((duration - timeLeft) / duration) * 100}%`;

                if (timeLeft <= 0) {
                    clearInterval(interval);
                    adOverlay.classList.add('hidden');
                    resolve(true);
                }
            }, 1000);
        });
    }

    async function requestRewardedAd(type, fallbackDuration) {
        if (rewardedAdBusy) return false;

        rewardedAdBusy = true;
        try {
            if (hasNativeRewardedAdBridge()) {
                return await showNativeRewardedAd(type);
            }

            return await startAdSimulation(fallbackDuration);
        } catch (error) {
            console.error('Rewarded ad failed:', error);
            const viewportCenter = getViewportCenter();
            spawnFloatText(viewportCenter.x, viewportCenter.y, '広告を読み込めませんでした');
            return false;
        } finally {
            rewardedAdBusy = false;
        }
    }

    function giveAdReward(type) {
        if (type === 'fever') {
            startFeverTime();
        } else if (type === 'jewel') {
            jewels += 5;
            updateDisplay();
            const viewportCenter = getViewportCenter();
            spawnFloatText(viewportCenter.x, viewportCenter.y, '+💎5');
        } else if (type === 'boost') {
            adBoostActive = true;
            boostEndTime = Date.now() + 600 * 1000; // 10分
            updateDisplay();
            const viewportCenter = getViewportCenter();
            spawnFloatText(viewportCenter.x, viewportCenter.y, 'PRODUCTION 2X!');
        } else if (type === 'offline_double') {
            const amount = pendingOfflineCookies * 2;
            cookies += amount;
            totalBaked += amount;
            pendingOfflineCookies = 0;
            offlineModal.classList.add('hidden');
            updateDisplay();
            const viewportCenter = getViewportCenter();
            spawnFloatText(viewportCenter.x, viewportCenter.y, `+${Math.floor(amount).toLocaleString()}`);
        } else if (type === 'daily_triple') {
            // 現在のCPSの3時間分をベースにする (最低1000枚)
            const base = Math.max(1000, totalCps * 3600);
            const cookiesAmount = base * 3;
            const jewelsAmount = 3 * 3;
            
            cookies += cookiesAmount;
            totalBaked += cookiesAmount;
            jewels += jewelsAmount;
            
            dailyModal.classList.add('hidden');
            updateDisplay();
            const viewportCenter = getViewportCenter();
            spawnFloatText(viewportCenter.x, viewportCenter.y, `+${Math.floor(cookiesAmount).toLocaleString()} cookies\n+💎${jewelsAmount}`);
        }
    }

    // デイリーボーナスのチェック
    function checkDailyBonus() {
        const today = new Date().toDateString();
        if (lastLoginDate !== today) {
            const baseReward = Math.max(1000, totalCps * 3600);
            dailyCookiesReward.textContent = Math.floor(baseReward).toLocaleString();
            dailyModal.classList.remove('hidden');
            lastLoginDate = today;
            saveGame();
        }
    }

    claimDailyBtn.addEventListener('click', () => {
        const baseReward = Math.max(1000, totalCps * 3600);
        cookies += baseReward;
        totalBaked += baseReward;
        jewels += 3;
        
        dailyModal.classList.add('hidden');
        updateDisplay();
        const viewportCenter = getViewportCenter();
        spawnFloatText(viewportCenter.x, viewportCenter.y, `+${Math.floor(baseReward).toLocaleString()} cookies\n+💎3`);
        saveGame();
    });

    adTripleDailyBtn.addEventListener('click', async () => {
        const rewarded = await requestRewardedAd('daily_triple', 15);
        if (!rewarded) return;
            giveAdReward('daily_triple');
            saveGame();
    });

    // 設定パネルの操作
    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.remove('hidden');
        updateDisplay();
    });

    soundToggleBtn.addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        updateSoundButton();
        saveGame();
    });

    function updateSoundButton() {
        if (soundEnabled) {
            soundToggleBtn.textContent = 'ON';
            soundToggleBtn.classList.add('on');
            soundToggleBtn.classList.remove('off');
        } else {
            soundToggleBtn.textContent = 'OFF';
            soundToggleBtn.classList.add('off');
            soundToggleBtn.classList.remove('on');
        }
    }

    resetBtnMain.addEventListener('click', () => {
        if (confirm('セーブデータを削除して最初からやり直しますか？')) {
            localStorage.removeItem('cookieClickerSave');
            location.reload();
        }
    });

    // オフライン報酬のチェック
    function checkOfflineBonus() {
        const now = Date.now();
        const elapsedSeconds = Math.floor((now - lastSaveTime) / 1000);
        
        // 1分以上、かつ生産力がある場合
        if (elapsedSeconds >= 60 && totalCps > 0) {
            // 最大24時間 (86400秒)
            const cappedSeconds = Math.min(elapsedSeconds, 86400);
            // 効率 50%
            const earnings = cappedSeconds * totalCps * 0.5;
            
            pendingOfflineCookies = earnings;
            offlineCookiesDisplay.textContent = Math.floor(earnings).toLocaleString();
            offlineModal.classList.remove('hidden');
        }
    }

    claimOfflineBtn.addEventListener('click', () => {
        cookies += pendingOfflineCookies;
        totalBaked += pendingOfflineCookies;
        const amount = pendingOfflineCookies;
        pendingOfflineCookies = 0;
        offlineModal.classList.add('hidden');
        updateDisplay();
        const viewportCenter = getViewportCenter();
        spawnFloatText(viewportCenter.x, viewportCenter.y, `+${Math.floor(amount).toLocaleString()}`);
        saveGame();
    });

    adDoubleOfflineBtn.addEventListener('click', async () => {
        const rewarded = await requestRewardedAd('offline_double', 10);
        if (!rewarded) return;
            giveAdReward('offline_double');
            saveGame();
    });

    function updateAutoClickerIndicator() {
        const isActive = premiumUpgrades['premium-autoclick'].purchased && premiumUpgrades['premium-autoclick'].level > 0;
        autoclickerStatus.classList.toggle('hidden', !isActive);
    }

    function startAutoClicker() {
        if (!premiumUpgrades['premium-autoclick'].purchased) return;
        
        // すでに動いている場合は一度クリア (レベルアップ時などの再起動用)
        if (window.autoClickInterval) clearInterval(window.autoClickInterval);

        // レベルに応じて速度アップ (1000msから開始、1Lvにつき200ms短縮、最短100ms)
        const speed = Math.max(100, 1000 - (premiumUpgrades['premium-autoclick'].level * 200));

        window.autoClickInterval = setInterval(() => {
            // 仮想的に中央をクリック
            const rect = cookieBtn.getBoundingClientRect();
            const x = rect.left + rect.width / 2;
            const y = rect.top + rect.height / 2;
            
            // クッキー加算ロジック (clickイベントを直接呼ぶのは座標が取れないため、ロジックを共通化)
            simulateCookieClick(x, y, { silentClickSound: true });
        }, speed);

        updateAutoClickerIndicator();
    }

    function simulateCookieClick(x, y, options = {}) {
        const { silentClickSound = false } = options;
        // 基本7倍 + プレミアム強化(1Lvにつき+5)
        const premiumFeverBonus = premiumUpgrades['premium-fever'].level * 5;
        const feverMult = isFeverActive ? (7 + premiumFeverBonus) : 1;
        
        // 基本倍率 × レベル (未購入時は1)
        const clickUpgradeMult = passiveBuffs['upgrade-click'].purchased ? (passiveBuffs['upgrade-click'].multiplier * passiveBuffs['upgrade-click'].level) : 1;
        const levelClickMult = getClickLevelBonusMultiplier();
        const adBoostMult = adBoostActive ? 2 : 1;
        
        // コンボボーナス (50コンボごとに +10% ずつ、最大 +100%)
        const comboBonus = Math.min(1.0, Math.floor(currentCombo / 50) * 0.1);
        const comboMult = 1.0 + comboBonus;

        // クリティカル判定 (5%の確率で 10倍)
        const isCritical = Math.random() < 0.05;
        const criticalMult = isCritical ? 10 : 1;

        const baseAmount = feverMult * clickUpgradeMult * levelClickMult * adBoostMult * comboMult;
        const amount = baseAmount * criticalMult;
        
        cookies += amount;
        totalBaked += amount;
        checkLevelUp();
        
        const now = Date.now();
        if (now - lastClickTime < 1000) {
            currentCombo++;
            if (currentCombo > maxCombo) maxCombo = currentCombo;
            
            // コンボ表示の更新
            if (currentCombo >= 2) {
                comboDisplay.classList.remove('hidden');
                comboDisplay.textContent = `${currentCombo} COMBO`;
                // コンボ数に応じて色や大きさを変える演出
                if (currentCombo >= 100) {
                    comboDisplay.style.color = '#fa5252';
                    comboDisplay.style.transform = 'translateX(-50%) scale(1.5)';
                } else if (currentCombo >= 50) {
                    comboDisplay.style.color = '#fab005';
                    comboDisplay.style.transform = 'translateX(-50%) scale(1.2)';
                } else {
                    comboDisplay.style.color = 'white';
                    comboDisplay.style.transform = 'translateX(-50%) scale(1.0)';
                }
            }
        } else {
            currentCombo = 1;
            comboDisplay.classList.add('hidden');
        }
        lastClickTime = now;

        if (!silentClickSound) {
            playClickSound();
        }
        
        // 叩いた時のアニメーション適用
        cookieBtn.classList.add('cookie-clicked');
        setTimeout(() => cookieBtn.classList.remove('cookie-clicked'), 100);

        if (isCritical) {
            spawnFloatText(x, y, `CRITICAL!! +${Math.floor(amount).toLocaleString()}`);
            playSpecialSound(660, 0.2); // クリティカル音
        } else {
            spawnFloatText(x, y, `+${Math.floor(amount).toLocaleString()}`);
        }
        updateDisplay();
    }

    // クッキーをクリック
    cookieBtn.addEventListener('click', (e) => {
        e.preventDefault(); // デフォルト動作（ズームなど）を防止
        simulateCookieClick(e.clientX, e.clientY);
    }, { passive: false });

    // 建物の購入処理
    document.querySelectorAll('.buy-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const parentId = e.target.closest('.upgrade-item').id;
            const upgrade = upgrades[parentId];
            
            if (cookies >= upgrade.cost) {
                cookies -= upgrade.cost;
                upgrade.count += 1;
                // 次のコストを計算 (1.15倍)
                upgrade.cost = upgrade.baseCost * Math.pow(1.15, upgrade.count);
                
                calculateCps();
                updateDisplay();
                saveGame();

                // 購入演出の発動 (アイテム名から絵文字を抽出)
                const itemName = e.target.closest('.upgrade-item').querySelector('.item-name').textContent;
                const emojiMatch = itemName.match(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}]/u);
                const emoji = emojiMatch ? emojiMatch[0] : '🏗️';
                triggerPurchaseEffect(emoji);
            }
        });
    });

    // アップグレードの購入処理
    document.querySelectorAll('.buy-upgrade-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const upgradeId = e.target.closest('.upgrade-item').id;
            const upgrade = passiveBuffs[upgradeId];
            const itemCard = e.target.closest('.upgrade-item');
            
            if (!upgrade.purchased) {
                // 初回購入 (クッキー)
                if (cookies >= upgrade.cost) {
                    cookies -= upgrade.cost;
                    upgrade.purchased = true;
                    upgrade.level = 1;
                    calculateCps();
                    updateDisplay();
                    saveGame();
                    
                    // 購入演出
                    const itemName = itemCard.querySelector('.item-name').textContent;
                    const emojiMatch = itemName.match(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}]/u);
                    const emoji = emojiMatch ? emojiMatch[0] : '✨';
                    triggerPurchaseEffect(emoji);
                }
            } else {
                const rewarded = await requestRewardedAd(`upgrade_${upgradeId}`, 10);
                if (!rewarded) return;
                    upgrade.level++;
                    calculateCps();
                    updateDisplay();
                    saveGame();
                    
                    const itemName = itemCard.querySelector('.item-name').textContent;
                    const emojiMatch = itemName.match(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}]/u);
                    const emoji = emojiMatch ? emojiMatch[0] : '🆙';
                    triggerPurchaseEffect(emoji);
            }
        });
    });

    // 表示更新
    function updateDisplay() {
        // ブースト期間の確認
        if (adBoostActive && Date.now() > boostEndTime) {
            adBoostActive = false;
        }

        updateAutoClickerIndicator();

        // フィーバー倍率: 基本7倍 + プレミアム強化(1Lvにつき+5)
        const premiumFeverBonus = premiumUpgrades['premium-fever'].level * 5;
        const feverMult = isFeverActive ? (7 + premiumFeverBonus) : 1;
        // 1.0 + (基本0.2 + (レベル-1) * 0.05)
        const globalLevelBonus = passiveBuffs['upgrade-global'].purchased ? (0.2 + (passiveBuffs['upgrade-global'].level - 1) * 0.05) : 0;
        const globalMult = 1.0 + globalLevelBonus;
        const cpsLevelMult = getCpsLevelBonusMultiplier();
        const adBoostMult = adBoostActive ? 2 : 1;
        
        const displayCps = totalCps * feverMult * globalMult * cpsLevelMult * adBoostMult;
        
        cookieCountDisplay.textContent = Math.floor(cookies).toLocaleString();
        if (jewelCountDisplay) jewelCountDisplay.textContent = jewels.toLocaleString();
        cpsDisplay.textContent = displayCps.toFixed(1);
        const currentLevelTarget = getLevelTarget(playerLevel);
        const nextLevelTarget = getLevelTarget(playerLevel + 1);
        const levelProgress = nextLevelTarget > currentLevelTarget ? ((totalBaked - currentLevelTarget) / (nextLevelTarget - currentLevelTarget)) * 100 : 100;
        playerLevelText.textContent = `Lv.${playerLevel} 次まで ${Math.max(0, Math.ceil(nextLevelTarget - totalBaked)).toLocaleString()}`;
        playerLevelProgress.style.width = `${Math.max(0, Math.min(100, levelProgress))}%`;

        let buyableBuildings = 0;
        let buildingCount = 0;

        // 各建物ボタンの更新
        Object.keys(upgrades).forEach(id => {
            const item = upgrades[id];
            const itemDiv = document.getElementById(id);
            if (!itemDiv) return;

            const button = itemDiv.querySelector('.buy-btn');
            const countDisplay = itemDiv.querySelector('.item-count');
            
            button.textContent = `${Math.floor(item.cost).toLocaleString()} cookies`;
            button.disabled = (cookies < item.cost);
            
            if (cookies >= item.cost) buyableBuildings++;
            
            countDisplay.textContent = item.count;
            buildingCount += item.count;
        });

        buildingBadge.textContent = buyableBuildings;
        buildingBadge.style.display = buyableBuildings > 0 ? 'block' : 'none';

        // アップグレードボタンの更新
        let buyableUpgrades = 0;
        Object.keys(passiveBuffs).forEach(id => {
            const upgrade = passiveBuffs[id];
            const itemDiv = document.getElementById(id);
            const button = itemDiv.querySelector('.buy-upgrade-btn');
            
            if (upgrade.purchased) {
                button.textContent = `🎬 広告で強化 (Lv.${upgrade.level})`;
                button.disabled = false; // 広告強化は常に可能
                itemDiv.style.opacity = '1.0';
                button.style.backgroundColor = '#4dabf7'; // 青色に変更して区別
            } else {
                button.textContent = `${Math.floor(upgrade.cost).toLocaleString()} cookies`;
                button.disabled = (cookies < upgrade.cost);
                button.style.backgroundColor = ''; // デフォルトに戻す
                if (cookies >= upgrade.cost) buyableUpgrades++;
            }
        });

        // プレミアムショップボタンの更新
        Object.keys(premiumUpgrades).forEach(id => {
            const upgrade = premiumUpgrades[id];
            const itemDiv = document.getElementById(id);
            const button = itemDiv.querySelector('.buy-premium-btn');
            const levelDisplay = itemDiv.querySelector('.item-count');
            if (!button) return;
            
            const currentCost = upgrade.baseCost * Math.pow(2, upgrade.level);
            levelDisplay.textContent = `Lv.${upgrade.level}`;
            button.textContent = `${currentCost} jewels`;
            button.disabled = (jewels < currentCost);
        });

        upgradeBadge.textContent = buyableUpgrades;
        upgradeBadge.style.display = buyableUpgrades > 0 ? 'block' : 'none';

        // ボーナス項目の更新 (クールダウン表示)
        let bonusAvailable = false;
        Object.keys(cooldowns).forEach(type => {
            const itemCard = document.getElementById(`bonus-ad-${type}`);
            if (!itemCard) return;
            const overlay = itemCard.querySelector('.cooldown-overlay');
            const timer = itemCard.querySelector('.cooldown-timer');
            const button = itemCard.querySelector('.ad-reward-btn');

            const now = Date.now();
            if (now < cooldowns[type]) {
                overlay.classList.remove('hidden');
                const remaining = Math.ceil((cooldowns[type] - now) / 1000);
                const min = Math.floor(remaining / 60);
                const sec = remaining % 60;
                timer.textContent = `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
                button.disabled = true;
            } else {
                overlay.classList.add('hidden');
                button.disabled = false;
                bonusAvailable = true;
            }
        });

        if (bonusBadge) bonusBadge.style.display = bonusAvailable ? 'block' : 'none';

        // 統計情報の更新
        statBonuses.textContent = bonusesEarned;
        statStartDate.textContent = gameStartDate;
        statTotalBaked.textContent = Math.floor(totalBaked).toLocaleString();
        statTotalBuildings.textContent = buildingCount;
        
        // クリック倍率の計算
        const clickLevelMult = passiveBuffs['upgrade-click'].purchased ? (passiveBuffs['upgrade-click'].multiplier * passiveBuffs['upgrade-click'].level) : 1;
        let clickPower = clickLevelMult * getClickLevelBonusMultiplier() * feverMult * adBoostMult;
        statCookiesPerClick.textContent = clickPower; 
        
        statMaxCombo.textContent = maxCombo;
    }

    // 浮遊テキストエフェクト
    function spawnFloatText(x, y, text) {
        const safePosition = clampEffectPosition(x, y);
        const span = document.createElement('span');
        span.className = 'float-text';
        if (isFeverActive) span.style.color = '#d4af37'; // フィーバー中は金色の文字
        span.textContent = text;
        span.style.left = `${safePosition.x}px`;
        span.style.top = `${safePosition.y}px`;
        document.body.appendChild(span);
        setTimeout(() => span.remove(), 800);
    }

    // お菓子が降ってくるエフェクト
    function spawnFallingCookie() {
        const sweets = ['🍪', '🍬', '🍨', '🍫', '🍰', '🍹', '🍭', '🍩', '🍮'];
        const randomSweet = sweets[Math.floor(Math.random() * sweets.length)];
        
        const cookie = document.createElement('div');
        cookie.className = 'falling-cookie';
        cookie.textContent = randomSweet;
        cookie.style.left = Math.random() * 100 + '%';
        const duration = isFeverActive ? (1.5 + Math.random() * 2) : (3 + Math.random() * 4);
        cookie.style.animationDuration = duration + 's';
        cookie.style.opacity = isFeverActive ? (0.6 + Math.random() * 0.4) : (0.4 + Math.random() * 0.4);
        cookie.style.fontSize = (isFeverActive ? (2 + Math.random() * 2) : (1.5 + Math.random() * 2)) + 'rem';
        
        playArea.appendChild(cookie);
        setTimeout(() => cookie.remove(), duration * 1000);
    }

    // 定期的に降らせる (CPSに応じて頻度を上げる)
    function startFallingCookies() {
        const baseInterval = 500; 
        
        function tick() {
            spawnFallingCookie();
            // 次の降ってくるまでの時間をCPSに基づいて計算 (最低50msまで短縮)
            // フィーバー中はさらに2倍の頻度
            let nextInterval = Math.max(50, baseInterval / (1 + totalCps / 5));
            if (isFeverActive) nextInterval /= 2;
            
            setTimeout(tick, nextInterval);
        }
        tick();
    }
    startFallingCookies();

    // 効果音 (Web Audio API を使用して簡易生成)
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    function playClickSound() {
        if (!soundEnabled) return;
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(110, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
    }

    function playSpecialSound(freq, duration) {
        if (!soundEnabled) return;
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(freq / 2, audioCtx.currentTime + duration);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + duration);
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
    }

    function playPurchaseSound() {
        if (!soundEnabled) return;
        if (audioCtx.state === 'suspended') audioCtx.resume();
        // レジの音を模した2段階の音
        const now = audioCtx.currentTime;
        [880, 1760].forEach((freq, i) => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now + i * 0.05);
            gain.gain.setValueAtTime(0.1, now + i * 0.05);
            gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.05 + 0.1);
            osc.start(now + i * 0.05);
            osc.stop(now + i * 0.05 + 0.1);
        });
    }

    // 購入時の派手な演出
    function triggerPurchaseEffect(emoji) {
        const viewportCenter = getViewportCenter();
        // 1. 画面フラッシュ
        const flash = document.createElement('div');
        flash.className = 'screen-flash';
        document.body.appendChild(flash);
        setTimeout(() => flash.remove(), 300);

        // 2. 絵文字の噴水
        for (let i = 0; i < 15; i++) {
            const particle = document.createElement('div');
            particle.className = 'purchase-particle';
            particle.textContent = emoji;
            particle.style.left = '50%';
            particle.style.top = '50%';
            
            // ランダムな方向と強さ
            const angle = (Math.random() * 360) * (Math.PI / 180);
            const velocity = 5 + Math.random() * 10;
            const vx = Math.cos(angle) * velocity;
            const vy = Math.sin(angle) * velocity - 10; // 上方向に強める
            
            document.body.appendChild(particle);
            
            let x = viewportCenter.x;
            let y = viewportCenter.y;
            let curVx = vx;
            let curVy = vy;
            const gravity = 0.5;
            
            const animate = () => {
                x += curVx;
                y += curVy;
                curVy += gravity;
                particle.style.transform = `translate(${x - viewportCenter.x}px, ${y - viewportCenter.y}px) rotate(${curVy * 10}deg)`;
                particle.style.opacity = parseFloat(particle.style.opacity || 1) - 0.02;
                
                if (y < (window.visualViewport ? window.visualViewport.height : window.innerHeight) + 50 && parseFloat(particle.style.opacity) > 0) {
                    requestAnimationFrame(animate);
                } else {
                    particle.remove();
                }
            };
            requestAnimationFrame(animate);
        }

        // 3. CPS数字のパンチ
        cpsDisplay.classList.add('stat-punch');
        setTimeout(() => cpsDisplay.classList.remove('stat-punch'), 500);
        
        // 4. 音
        playPurchaseSound();
    }
    // CPS (Cookies Per Second) の計算
    function calculateCps() {
        totalCps = 0;
        Object.keys(upgrades).forEach(id => {
            let itemCps = upgrades[id].count * upgrades[id].cps;
            
            // 建物特化の強化を適用
            Object.values(passiveBuffs).forEach(buff => {
                if (buff.purchased && buff.type === 'building' && buff.target === id) {
                    // 基本倍率 × レベル
                    itemCps *= (buff.multiplier * buff.level);
                }
            });
            
            totalCps += itemCps;
        });
    }

    // 毎秒の自動加算 (および表示の定期更新)
    setInterval(() => {
        // CPSによる加算
        if (totalCps > 0) {
            const premiumFeverBonus = premiumUpgrades['premium-fever'].level * 5;
            const feverMult = isFeverActive ? (7 + premiumFeverBonus) : 1;
            const globalLevelBonus = passiveBuffs['upgrade-global'].purchased ? (0.2 + (passiveBuffs['upgrade-global'].level - 1) * 0.05) : 0;
            const globalMult = 1.0 + globalLevelBonus;
            const cpsLevelMult = getCpsLevelBonusMultiplier();
            const adBoostMult = adBoostActive ? 2 : 1;
            const added = (totalCps * feverMult * globalMult * cpsLevelMult * adBoostMult) / 10;
            cookies += added;
            totalBaked += added;
            checkLevelUp();
        }
        
        // クールダウンやブースト時間の更新のために常に表示更新を行う
        updateDisplay();
    }, 100);

    // セーブ・ロード機能
    function saveGame() {
        lastSaveTime = Date.now();
        const saveData = {
            cookies,
            jewels,
            totalBaked,
            playerLevel,
            bonusesEarned,
            gameStartDate,
            maxCombo,
            upgrades,
            passiveBuffs,
            premiumUpgrades,
            adBoostActive,
            boostEndTime,
            cooldowns,
            lastSaveTime,
            soundEnabled,
            lastLoginDate
        };
        localStorage.setItem('cookieClickerSave', JSON.stringify(saveData));
    }

    function loadGame() {
        const saved = localStorage.getItem('cookieClickerSave');
        if (saved) {
            const data = JSON.parse(saved);
            cookies = data.cookies || 0;
            jewels = data.jewels || 0;
            totalBaked = data.totalBaked || 0;
            playerLevel = data.playerLevel || 1;
            bonusesEarned = data.bonusesEarned || 0;
            gameStartDate = data.gameStartDate || new Date().toLocaleString();
            maxCombo = data.maxCombo || 0;
            adBoostActive = data.adBoostActive || false;
            boostEndTime = data.boostEndTime || 0;
            lastSaveTime = data.lastSaveTime || Date.now();
            soundEnabled = data.soundEnabled !== undefined ? data.soundEnabled : true;
            lastLoginDate = data.lastLoginDate || "";
            if (data.cooldowns) cooldowns = data.cooldowns;
            
            updateSoundButton();
            
            if (data.upgrades) {
                Object.keys(data.upgrades).forEach(id => {
                    if (upgrades[id]) {
                        upgrades[id].count = data.upgrades[id].count;
                        upgrades[id].cost = data.upgrades[id].cost;
                    }
                });
            }

            if (data.passiveBuffs) {
                Object.keys(data.passiveBuffs).forEach(id => {
                    if (passiveBuffs[id]) {
                        passiveBuffs[id].purchased = data.passiveBuffs[id].purchased;
                        passiveBuffs[id].level = data.passiveBuffs[id].level || 1;
                    }
                });
            }

            if (data.premiumUpgrades) {
                Object.keys(data.premiumUpgrades).forEach(id => {
                    if (premiumUpgrades[id]) {
                        premiumUpgrades[id].purchased = data.premiumUpgrades[id].purchased;
                        premiumUpgrades[id].level = data.premiumUpgrades[id].level || 0;
                        if (id === 'premium-autoclick' && premiumUpgrades[id].level > 0) {
                            startAutoClicker();
                        }
                    }
                });
            }

            while (totalBaked >= getLevelTarget(playerLevel + 1)) {
                playerLevel++;
            }

            calculateCps();
            updateDisplay();
        }
    }

    // オートセーブ (30秒ごと)
    setInterval(saveGame, 30000);

    runStartupSequence();
});
